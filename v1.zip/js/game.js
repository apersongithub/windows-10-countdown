/* ============================================================================
   Defender Game - Full game.js (Updated with text centering fix & simplified power-up visuals)
   Features:
   - Normal falling data blocks with accurate text centering & dynamic width
   - Life (HP) Block (minimal glow + icon + vanish animation)
   - Bomb (multi-spawn, image-based, explosion animation)
   - SNIP Power-Up (area selection / rectangle clear)
   - Shield Power-Up (temporary immunity + aura; pickup icon minimal glow)
   - Task Manager Power-Up (rare, clears all visible blocks, optional slow-mo)
   - Vanish animation for all collectible blocks (life, snip, shield, taskmgr, normal)
   - Boss encounter with hazards & death animation
   - Screen shake system, catch/miss FX, particles, ring pulses
   - Persistent high score & infinite mode unlock
   - Nuke / redirect logic on loss (config)
   - Pixel Taskbar Paddle
   - Audio parity via AUDIO config
   ============================================================================ */

import {
  HIGH_SCORE_KEY, SIZE_TIERS, DIFFICULTY, BLOCK_STYLE, EFFECTS,
  BOSS_CONFIG, HAZARDS, HAZARD_SPEED, REQUIRE_PERFECT_VICTORY,
  REDIRECT_ON_LOSS, LOSS_REDIRECT_URL, LS_KEYS, LIFE_BLOCK,
  AUDIO, TASKBAR_STYLE, BOMB_CONFIG, SNIP_POWERUP,
  SHIELD_POWERUP, TASKMGR_POWERUP
} from './config.js';
import { randBetween, roundedRect } from './utils.js';
import { triggerNuke } from './nuke.js';

/* -------------------- Core / Shared Constants -------------------- */
const INFINITE_UNLOCK_KEY = LS_KEYS.infinite;
const BASE_OVERLAY_BG = 'rgba(0,44,92,0.85)';
const START_IMMUNITY_MS = 300;
const SHOW_ESU_SCREEN = true;

/* Boss death animation constants */
const BOSS_DEATH_DURATION = 1600;
const BOSS_DEATH_FLASH_FREQ = 110;
const BOSS_DEATH_PARTICLE_COUNT = 70;
const BOSS_DEATH_PARTICLE_LIFE = 1400;
const BOSS_DEATH_PARTICLE_SIZE = [5, 18];
const BOSS_DEATH_PARTICLE_SPEED = [80, 440];
const BOSS_DEATH_PARTICLE_SPIN = [-600, 600];

/* Screen shake presets */
const SHAKE_DAMAGE_INTENSITY = 14;
const SHAKE_DAMAGE_DURATION = 180;
const SHAKE_DEATH_INTENSITY = 34;
const SHAKE_DEATH_DURATION = 550;
const SHAKE_LIFE_LOST_INTENSITY = 9;
const SHAKE_LIFE_LOST_DURATION = 260;

/* Other FX */
const CATCH_PARTICLE_COUNT_BASE = 10;
const SMALL_BLOCK_LABELS = new Set(['4KB', '5KB']);
const LIFE_PULSE_RADIUS = 70;

/* Bomb fallback explosion constants */
const BOMB_EXPLOSION_DURATION = BOMB_CONFIG.explosionDuration || 620;
const BOMB_SHARD_COUNT = BOMB_CONFIG.explosionShardCount || 28;
const BOMB_SHARD_SPEED = BOMB_CONFIG.explosionShardSpeedRange || [180, 520];
const BOMB_SHARD_SIZE = BOMB_CONFIG.explosionShardSizeRange || [4, 14];

/* Vanish animation config */
const POWERUP_VANISH_DURATION = 520; // ms
const POWERUP_VANISH_SCALE = 1.45;

/* -------------------- Persistent State -------------------- */
let highScore = parseInt(localStorage.getItem(HIGH_SCORE_KEY) || '0', 10) || 0;
let newHigh = false;
let infiniteUnlocked = localStorage.getItem(INFINITE_UNLOCK_KEY) === '1';
let infiniteMode = false;

/* -------------------- Runtime State -------------------- */
let gameActive = false;
let gamePaused = false;
let nukeTriggered = false;

let score = 0;
let lives = DIFFICULTY.lives;
let spawnInterval = DIFFICULTY.baseSpawnInterval;
let lastSpawn = 0;

let blocks = []; // normal, life, bomb, snip, shield, taskmgr, bossHazard
let paddleX = 0;
let canvas, ctx, hudEl, overlayEl, msgEl;
let rafId = null;
let lastTs = 0;

/* Boss state */
let bossActive = false;
let bossHealth = BOSS_CONFIG.health;
let bossDropInterval = BOSS_CONFIG.dropIntervalStart;
let lastBossDrop = 0;
let bossStartTime = 0;

/* Start time & life block spawn gating */
let gameStartTime = 0;
let lastLifeSpawnScore = 0;

/* Boss death animation */
let bossDying = false;
let bossDeathStart = 0;
let bossDeathParticles = [];

/* Screen shake */
let shakeStart = 0;
let shakeDuration = 0;
let shakeIntensity = 0;
let shakeMode = 'all';

/* FX arrays */
let catchParticles = [];
let floatTexts = [];
let ringPulses = [];
let powerupVanishFX = [];

/* Images */
let bossLogoImg = null; let bossLogoReady = false;
let bombImg = null; let bombImgReady = false;
let snipImg = null; let snipImgReady = false;
let lifeImg = null; let lifeImgReady = false;
let shieldImg = null; let shieldImgReady = false;
let taskMgrImg = null; let taskMgrImgReady = false;

/* Audio system */
const audioBank = {};
let audioLoaded = false;

/* Bomb spawn timing */
let lastBombSpawn = 0;
let nextBombSpawnDelay = 0;

/* SNIP power-up state */
let lastSnipSpawn = 0;
let nextSnipSpawnDelay = 0;
let snipReady = false;
let snipAimStart = 0;
let snipDragging = false;
let snipDragStarted = false;
let snipRect = null;
let snipDragOrigin = null;
let snipExecuted = false;

/* Shield power-up state */
let lastShieldSpawn = 0;
let nextShieldSpawnDelay = 0;
let shieldActive = false;
let shieldEndTime = 0;

/* Task Manager power-up state */
let lastTaskMgrSpawn = 0;
let nextTaskMgrSpawnDelay = 0;
let slowMoActive = false;
let slowMoEnd = 0;
let slowMoFactor = 1;

let lifeEverLost = false;

/* -------------------- Asset Loading -------------------- */
function loadBossLogo() {
  if (bossLogoImg || bossLogoReady) return;
  bossLogoImg = new Image();
  bossLogoImg.onload = () => bossLogoReady = true;
  bossLogoImg.onerror = () => bossLogoReady = false;
  bossLogoImg.src = BOSS_CONFIG.logoSrc;
}
function loadBombImage() {
  if (bombImg || bombImgReady) return;
  if (!BOMB_CONFIG.imageSrc) return;
  bombImg = new Image();
  bombImg.onload = () => bombImgReady = true;
  bombImg.onerror = () => bombImgReady = false;
  bombImg.src = BOMB_CONFIG.imageSrc;
}
function loadSnipImage() {
  if (snipImg || snipImgReady) return;
  if (!SNIP_POWERUP.imageSrc) return;
  snipImg = new Image();
  snipImg.onload = () => snipImgReady = true;
  snipImg.onerror = () => snipImgReady = false;
  snipImg.src = SNIP_POWERUP.imageSrc;
}
function loadLifeImage() {
  if (lifeImg || lifeImgReady) return;
  if (!LIFE_BLOCK.imageSrc) return;
  lifeImg = new Image();
  lifeImg.onload = () => lifeImgReady = true;
  lifeImg.onerror = () => lifeImgReady = false;
  lifeImg.src = LIFE_BLOCK.imageSrc;
}
function loadShieldImage() {
  if (shieldImg || shieldImgReady) return;
  if (!SHIELD_POWERUP.imageSrc) return;
  shieldImg = new Image();
  shieldImg.onload = () => shieldImgReady = true;
  shieldImg.onerror = () => shieldImgReady = false;
  shieldImg.src = SHIELD_POWERUP.imageSrc;
}
function loadTaskMgrImage() {
  if (taskMgrImg || taskMgrImgReady) return;
  if (!TASKMGR_POWERUP.imageSrc) return;
  taskMgrImg = new Image();
  taskMgrImg.onload = () => taskMgrImgReady = true;
  taskMgrImg.onerror = () => taskMgrImgReady = false;
  taskMgrImg.src = TASKMGR_POWERUP.imageSrc;
}
function loadAllImages() {
  loadBossLogo();
  loadBombImage();
  loadSnipImage();
  loadLifeImage();
  loadShieldImage();
  loadTaskMgrImage();
}

/* Audio loading */
function loadAudioBank() {
  if (audioLoaded || !AUDIO.enabled) return;
  for (const [key, path] of Object.entries(AUDIO.files)) {
    if (!path) continue;
    const a = new Audio(path);
    a.preload = 'auto';
    a.volume = (AUDIO.volumeMaster ?? 1) * (AUDIO.perClipVolume?.[key] ?? 1);
    audioBank[key] = a;
  }
  audioLoaded = true;
}
function playSfx(key, { allowOverlap = true } = {}) {
  if (!AUDIO.enabled) return;
  const clip = audioBank[key];
  if (!clip) return;
  if (!allowOverlap && !clip.paused) return;
  try { clip.currentTime = 0; clip.play(); } catch { }
}

/* -------------------- Text Measurement & Drawing (Normal Blocks) -------------------- */
function measureBlockText(label, font) {
  ctx.save();
  ctx.font = font;
  const metrics = ctx.measureText(label);
  const ascent = metrics.actualBoundingBoxAscent || metrics.emHeightAscent || 10;
  const descent = metrics.actualBoundingBoxDescent || metrics.emHeightDescent || 4;
  ctx.restore();
  return { width: metrics.width, ascent, descent };
}

function drawNormalBlock(b) {
  // Background
  ctx.fillStyle = b.caught ? BLOCK_STYLE.caughtColor : BLOCK_STYLE.bgColor;
  roundedRect(ctx, b.x, b.y, b.w, b.h, BLOCK_STYLE.cornerRadius);

  const font = BLOCK_STYLE.textFont;
  const { width, ascent, descent } = measureBlockText(b.label, font);
  const centerX = b.x + b.w / 2;
  const centerY = b.y + b.h / 2;
  const halfTextHeight = (ascent + descent) / 2;
  const textY = centerY + (ascent - halfTextHeight); // center using alphabetic baseline

  ctx.save();
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = b.caught ? BLOCK_STYLE.caughtText : (b.textColor || BLOCK_STYLE.textColor);
  ctx.fillText(b.label, centerX, textY);

  if (!b.caught && b.glowColor) {
    ctx.globalAlpha = 0.55;
    ctx.shadowColor = b.glowColor;
    ctx.shadowBlur = 14;
    ctx.fillStyle = b.textColor || BLOCK_STYLE.textColor;
    ctx.fillText(b.label, centerX, textY);
  }
  ctx.restore();
}

/* -------------------- Vanish Animation -------------------- */
function spawnPowerupVanishFX(options) {
  powerupVanishFX.push({
    ...options,
    start: performance.now(),
    duration: POWERUP_VANISH_DURATION
  });
}
function updateRenderVanishFX(now) {
  for (let i = powerupVanishFX.length - 1; i >= 0; i--) {
    const fx = powerupVanishFX[i];
    const t = (now - fx.start) / fx.duration;
    if (t >= 1) { powerupVanishFX.splice(i, 1); continue; }
    const ease = t * t * (3 - 2 * t); // smoothstep
    const scale = 1 + (POWERUP_VANISH_SCALE - 1) * ease;
    const alpha = 1 - t;

    ctx.save();
    ctx.globalAlpha = alpha * 0.55;
    ctx.fillStyle = fx.color || 'rgba(255,255,255,0.5)';
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, (fx.baseRadius || 28) * scale + 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = alpha;

    if (fx.imgReady) {
      const size = (fx.baseRadius || 28) * 2 * (fx.iconScale || 0.7) * scale;
      const prev = ctx.imageSmoothingEnabled;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(fx.img, fx.x - size / 2, fx.y - size / 2, size, size);
      ctx.imageSmoothingEnabled = prev;
    } else if (fx.label) {
      ctx.font = `700 ${Math.round((fx.baseRadius || 28) * scale)}px Segoe UI, Inter, sans-serif`;
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(fx.label, fx.x, fx.y + 2);
    }
    ctx.restore();
  }
}

/* -------------------- Taskbar Paddle -------------------- */
function drawTaskbarPaddle(x, y, width) {
  if (!TASKBAR_STYLE?.enabled) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, DIFFICULTY.paddleWidth, DIFFICULTY.paddleHeight);
    return;
  }
  const s = TASKBAR_STYLE;
  const px = s.pixel;
  const h = Math.max(DIFFICULTY.paddleHeight, s.height);
  const w = width;

  ctx.save(); ctx.globalAlpha = 0.9; ctx.fillStyle = s.glow;
  ctx.fillRect(x - 4, y - 6, w + 8, h + 12); ctx.restore();

  ctx.fillStyle = s.outline;
  ctx.fillRect(x, y, w, h);

  const innerX = x + px, innerY = y + px;
  const innerW = w - 2 * px, innerH = h - 2 * px;
  const bandH = Math.floor(innerH / 3);
  ctx.fillStyle = s.bgTop; ctx.fillRect(innerX, innerY, innerW, bandH);
  ctx.fillStyle = s.bgMid; ctx.fillRect(innerX, innerY + bandH, innerW, bandH);
  ctx.fillStyle = s.bgBottom; ctx.fillRect(innerX, innerY + bandH * 2, innerW, innerH - bandH * 2);
  ctx.fillStyle = s.innerLine; ctx.fillRect(innerX, innerY + bandH, innerW, px);

  const iconY = innerY + innerH / 2; let cursorX = innerX + s.padX;
  const minSpace = s.iconSize + s.padX;
  const drawStart = () => {
    const size = s.iconSize; const half = Math.floor(size / 2);
    ctx.fillStyle = s.startRed; ctx.fillRect(cursorX, iconY - half, half - 1, half - 1);
    ctx.fillStyle = s.startGreen; ctx.fillRect(cursorX + half + 1, iconY - half, half - 1, half - 1);
    ctx.fillStyle = s.startBlue; ctx.fillRect(cursorX, iconY + 1, half - 1, half - 1);
    ctx.fillStyle = s.startYellow; ctx.fillRect(cursorX + half + 1, iconY + 1, half - 1, half - 1);
    cursorX += size + s.iconGap;
  };
  const drawSearch = () => {
    const size = s.iconSize; const r = Math.floor(size / 2) - 2;
    const cx = cursorX + r + 1, cy = iconY;
    ctx.strokeStyle = '#b7c4ce'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx + r - 1, cy + r - 1); ctx.lineTo(cx + r + 5, cy + r + 5); ctx.stroke();
    cursorX += size + s.iconGap;
  };
  const drawFolder = () => {
    const size = s.iconSize;
    ctx.fillStyle = '#ffcf4d'; ctx.fillRect(cursorX, iconY - size / 2 + 1, size, size - 2);
    ctx.fillStyle = '#ffe28a'; ctx.fillRect(cursorX + 1, iconY - size / 2 + 2, size - 2, 4);
    cursorX += size + s.iconGap;
  };
  const drawEdge = () => {
    const size = s.iconSize; const r = size / 2;
    const cx = cursorX + r, cy = iconY;
    const grad = ctx.createRadialGradient(cx, cy - 2, 2, cx, cy, r);
    grad.addColorStop(0, '#0a84ff'); grad.addColorStop(1, '#0264c8');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(cx, cy, r - 1, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 8px Segoe UI,sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('e', cx, cy + 1);
    cursorX += size + s.iconGap;
  };

  if (cursorX + minSpace < x + w) drawStart();
  if (cursorX + minSpace < x + w) drawSearch();
  if (cursorX + minSpace < x + w) drawFolder();
  if (cursorX + minSpace < x + w) drawEdge();

  const indicatorW = 6;
  if (x + w - indicatorW - s.padX > cursorX + 20) {
    ctx.fillStyle = s.accentBlue;
    ctx.fillRect(x + w - indicatorW - s.padX,
      innerY + innerH - px * 3,
      indicatorW,
      px * 2);
  }
}

/* -------------------- Public API -------------------- */
export function showPlayPrompt() {
  const el = document.getElementById('play-prompt');
  el.textContent = infiniteUnlocked
    ? 'Press G to play (boss) or I for Infinite Mode'
    : 'Press G to defend against the update';
  el.style.display = 'block';
}
export function hidePlayPrompt() {
  const el = document.getElementById('play-prompt');
  if (el) el.style.display = 'none';
}
export function initGame() { }

/* -------------------- Internal Start -------------------- */
function internalStartCommon() {
  canvas = document.getElementById('game-canvas');
  ctx = canvas.getContext('2d');
  hudEl = document.getElementById('game-hud');
  overlayEl = document.getElementById('game-overlay');
  msgEl = document.getElementById('game-message');

  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('touchmove', onTouchMove, { passive: false });
  window.addEventListener('keydown', onGameKey);
  window.addEventListener('mousedown', onPointerDown);
  window.addEventListener('mouseup', onPointerUp);
  window.addEventListener('mousemove', onPointerMove);
  window.addEventListener('touchstart', onTouchStart, { passive: false });
  window.addEventListener('touchend', onTouchEnd);
  window.addEventListener('touchmove', onTouchDrag, { passive: false });

  hidePlayPrompt();
  overlayEl.style.display = 'block';

  score = 0;
  lives = DIFFICULTY.lives;
  lifeEverLost = false;
  newHigh = false;
  spawnInterval = DIFFICULTY.baseSpawnInterval;
  blocks = [];
  paddleX = canvas.width / 2 - DIFFICULTY.paddleWidth / 2;

  bossActive = false;
  bossHealth = BOSS_CONFIG.health;
  bossDropInterval = BOSS_CONFIG.dropIntervalStart;
  lastBossDrop = 0;
  bossStartTime = 0;

  lastLifeSpawnScore = 0;
  bossDying = false;
  bossDeathParticles = [];

  shakeStart = 0;
  catchParticles = [];
  floatTexts = [];
  ringPulses = [];
  powerupVanishFX = [];

  lastBombSpawn = performance.now();
  nextBombSpawnDelay = BOMB_CONFIG.spawnIntervalInitial;
  lastSnipSpawn = performance.now();
  nextSnipSpawnDelay = SNIP_POWERUP.spawnIntervalInitial;
  lastShieldSpawn = performance.now();
  nextShieldSpawnDelay = SHIELD_POWERUP.spawnIntervalInitial;
  lastTaskMgrSpawn = performance.now();
  nextTaskMgrSpawnDelay = TASKMGR_POWERUP.spawnIntervalInitial;

  resetSnipState();
  shieldActive = false;
  slowMoActive = false;
  slowMoFactor = 1;

  nukeTriggered = false;
  gameActive = true;
  gamePaused = false;
  gameStartTime = performance.now();
  lastTs = gameStartTime;
  lastSpawn = gameStartTime;

  msgEl.textContent = '';
  msgEl.classList.remove('show');
  if (flashBG._t) { clearTimeout(flashBG._t); flashBG._t = null; }
  overlayEl.style.background = BASE_OVERLAY_BG;

  loadAudioBank();
  loadAllImages();
  playSfx('uiStart');

  maybeShowTutorial(() => { rafId = requestAnimationFrame(gameLoop); });
}

export function startGame() { infiniteMode = false; internalStartCommon(); }
export function startInfiniteGame() { infiniteMode = true; internalStartCommon(); }

/* -------------------- Tutorial (condensed) -------------------- */
function maybeShowTutorial(cb){
  const seen = localStorage.getItem(LS_KEYS.tutorial)==='1';
  if (seen){
    // Tutorial already done: show the banner right away
    showStartLivesBanner();
    cb && cb();
    return;
  }

  const panel=document.createElement('div');
  panel.id='tutorial-overlay';
  panel.style.cssText=`
    position:fixed;inset:0;z-index:200;background:rgba(0,0,0,0.55);
    backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;
    font-family:inherit;color:#fff;padding:1.5rem;`;

  panel.innerHTML = `
    <div style="max-width:720px;width:100%;background:rgba(0,46,95,0.9);
      border:1px solid rgba(255,255,255,0.25);padding:1.75rem 2rem;font-size:.95rem;line-height:1.45;">
      <h2 style="margin:0 0 1rem;font-weight:400;font-size:1.4rem;">How to Play</h2>
      <ul style="margin:0 0 1.1rem 1.1rem;list-style:disc;">
        <li>The game progressively gets harder as time passes.</li>
        <li>When you lose something funny happens. (just click back button)</li>
        <li>Catch normal blocks for score; miss = lose life.</li>
        <li>Cortana: adds lives (up to ${LIFE_BLOCK.maxLives}).</li>
        <li>Error: avoid (explode & cost life unless shield).</li>
        <li>Snippping Tool: collect then drag rectangle to clear blocks.</li>
        <li>Shield: temporary immunity (${SHIELD_POWERUP.durationMs / 1000}s).</li>
        <li>Task Manager: rare; clears all visible blocks.</li>
        <li>Boss at ${BOSS_CONFIG.triggerScore} points. If you win you get a new gamemode.</li>
        <li>Complete the game without losing any lives for an easter egg :)</li>
        <li><strong>Go in fullscreen for the best experience</strong></li>
      </ul>
      <p style="margin:0 0 1.1rem;">Mouse/Touch, A/← & D/→ move, P pause, Esc exit, G start, I infinite</p>
      <button id="tutorial-start"
        style="background:#fff;color:#003a66;border:0;padding:.6rem 1.2rem;cursor:pointer;
          font:inherit;font-size:.8rem;letter-spacing:.5px;">START</button>
    </div>`;

  document.body.appendChild(panel);

  function closeTutorial(){
    try { localStorage.setItem(LS_KEYS.tutorial,'1'); } catch {}
    panel.remove();
    // Only show the lives banner NOW (after tutorial actually dismissed)
    showStartLivesBanner();
    // Reset timing anchors just like before
    gameStartTime = performance.now();
    lastTs = gameStartTime;
    lastSpawn = gameStartTime;
    rafId = requestAnimationFrame(gameLoop);
    cb && cb();
  }

  panel.querySelector('#tutorial-start').addEventListener('click', ()=>{
    playSfx('uiSelect');
    closeTutorial();
  });

  window.addEventListener('keydown', function k(ev){
    if (['Enter',' '].includes(ev.key)){ 
      window.removeEventListener('keydown', k);
      playSfx('uiSelect');
      closeTutorial();
    } else if (ev.key === 'Escape') {
      // (Optional) allow skipping tutorial – if you DON'T want skipping, remove this branch.
      window.removeEventListener('keydown', k);
      playSfx('uiSelect');
      closeTutorial();
    }
  });
}

/* -------------------- Unlock Infinite -------------------- */
function unlockInfinite() {
  if (!infiniteUnlocked) {
    infiniteUnlocked = true;
    try { localStorage.setItem(INFINITE_UNLOCK_KEY, '1'); } catch { }
    playSfx('infiniteUnlock');
  }
}

/* -------------------- Life Blocks -------------------- */
function maybeSpawnLifeBlock() {
  if (bossActive || bossDying) return;
  if (lives >= LIFE_BLOCK.maxLives) return;
  const interval = infiniteMode ? LIFE_BLOCK.infiniteInterval : LIFE_BLOCK.normalInterval;
  if (!interval) return;
  if (score <= 0) return;
  if (score % interval !== 0) return;
  if (lastLifeSpawnScore === score) return;
  lastLifeSpawnScore = score;
  spawnLifeBlock();
}
function spawnLifeBlock() {
  loadLifeImage();
  const size = LIFE_BLOCK.size;
  const x = Math.random() * (canvas.width - size - 80) + 40;
  const speed = DIFFICULTY.baseSpeedRange[1] * LIFE_BLOCK.speedMultiplier;
  blocks.push({
    mode: 'life',
    label: LIFE_BLOCK.label,
    x, y: -size - 8,
    w: size, h: size,
    speed,
    caught: false,
    created: performance.now()
  });
}

/* -------------------- Bomb Spawning -------------------- */
function maybeSpawnBomb(ts) {
  if (!BOMB_CONFIG.enabled) return;
  if (bossActive || bossDying || snipReady) return;
  if (!gameActive) return;
  const elapsed = ts - lastBombSpawn;
  if (elapsed < nextBombSpawnDelay) return;
  const ratio = Math.min(1, score / BOMB_CONFIG.spawnIntervalDecayScore);
  const baseInterval = BOMB_CONFIG.baseSpawnInterval -
    (BOMB_CONFIG.baseSpawnInterval - BOMB_CONFIG.spawnIntervalMin) * ratio;
  let cycles = 1;
  if (BOMB_CONFIG.backfillCatchUp) cycles = Math.min(4, Math.max(1, Math.floor(elapsed / baseInterval)));
  for (let c = 0; c < cycles; c++) { spawnBombBurst(); lastBombSpawn = ts; }
  nextBombSpawnDelay = baseInterval + Math.random() * BOMB_CONFIG.randomJitter;
}
function currentActiveBombs() { return blocks.filter(b => b.mode === 'bomb' && !b._remove).length; }
function spawnBombBurst() {
  if (currentActiveBombs() >= BOMB_CONFIG.maxConcurrent) return;
  spawnBomb();
  const ratio = Math.min(1, score / (BOMB_CONFIG.scoreRampForMulti || 1));
  const chance = BOMB_CONFIG.multiSpawnChanceBase + ratio * BOMB_CONFIG.multiSpawnChanceScoreBoost;
  let extra = 0;
  while (extra < BOMB_CONFIG.multiSpawnMax) {
    if (currentActiveBombs() >= BOMB_CONFIG.maxConcurrent) break;
    if (Math.random() < chance) { spawnBomb(); extra++; } else break;
  }
  playSfx('bombSpawn');
}
function spawnBomb() {
  loadBombImage();
  const size = BOMB_CONFIG.size;
  const x = Math.random() * (canvas.width - size - 80) + 40;
  const speed = randBetween(...BOMB_CONFIG.speedRange);
  blocks.push({
    mode: 'bomb',
    x, y: -size - 10,
    w: size, h: size,
    speed,
    caught: false,
    created: performance.now(),
    lastSpark: performance.now(),
    exploding: false,
    explodeStart: 0,
    shards: []
  });
}

/* -------------------- SNIP Power-Up -------------------- */
function maybeSpawnSnip(ts) {
  if (!SNIP_POWERUP.enabled) return;
  if (bossActive || bossDying || snipReady) return;
  if (!gameActive) return;
  if (countActiveSnipPowerups() >= SNIP_POWERUP.maxConcurrent) return;
  const elapsed = ts - lastSnipSpawn;
  if (elapsed < nextSnipSpawnDelay) return;
  const ratio = Math.min(1, score / SNIP_POWERUP.spawnIntervalDecayScore);
  const baseI = SNIP_POWERUP.baseSpawnInterval -
    (SNIP_POWERUP.baseSpawnInterval - SNIP_POWERUP.spawnIntervalMin) * ratio;
  let cycles = 1;
  if (SNIP_POWERUP.backfillCatchUp) cycles = Math.min(3, Math.max(1, Math.floor(elapsed / baseI)));
  if (cycles > 0) { spawnSnipPowerup(); lastSnipSpawn = ts; }
  nextSnipSpawnDelay = baseI + Math.random() * SNIP_POWERUP.randomJitter;
}
function countActiveSnipPowerups() { return blocks.filter(b => b.mode === 'snip' && !b.caught).length; }
function spawnSnipPowerup() {
  loadSnipImage();
  const size = SNIP_POWERUP.size;
  const x = Math.random() * (canvas.width - size - 80) + 40;
  const speed = randBetween(140, 260);
  blocks.push({
    mode: 'snip',
    label: SNIP_POWERUP.label,
    x, y: -size - 10,
    w: size, h: size,
    speed,
    caught: false,
    created: performance.now()
  });
  playSfx('snipSpawn');
}
function resetSnipState() {
  snipReady = false; snipAimStart = 0; snipDragging = false;
  snipDragStarted = false; snipRect = null; snipDragOrigin = null; snipExecuted = false;
}
function beginSnipReady() {
  snipReady = true; snipAimStart = performance.now();
  snipDragOrigin = null; snipRect = null;
  snipDragging = false; snipDragStarted = false; snipExecuted = false;
  playSfx('snipPickup');
}
// --- REPLACEMENT executeSnip IMPLEMENTATION ---
function executeSnip(rect) {
  if (!rect) return;
  snipExecuted = true;
  playSfx('snipExecute');
  if (SNIP_POWERUP.screenShakeOnExecute) {
    triggerShake(
      SNIP_POWERUP.executeShakeIntensity,
      SNIP_POWERUP.executeShakeDuration,
      'all'
    );
  }

  const rx = rect.x, ry = rect.y, rw = rect.w, rh = rect.h;
  const now = performance.now();

  let normalCleared = 0;
  let bombsTouched = 0;

  // Power-up collection tracking
  let shieldCollected = false;
  let taskMgrCollected = false;
  let lifeCollectedCount = 0;
  // let extraSnipCharge = false; // (Optional) chained snip

  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i];
    if (b.caught) continue;

    // Skip hazards or the live snip icon itself
    if (b.mode === 'bossHazard') continue;
    if (b.mode === 'snip' && snipReady && !b.caught) continue;

    if (!intersectRect(rx, ry, rw, rh, b.x, b.y, b.w, b.h)) continue;

    switch (b.mode) {
      case 'normal': {
        normalCleared++;
        score += SNIP_POWERUP.awardScorePerNormal;
        spawnCatchParticles(b.x + b.w/2, b.y + b.h/2, '#ff9de0', 12);
        spawnFloatText(
          b.x + b.w/2,
          b.y + b.h/2,
          `+${SNIP_POWERUP.awardScorePerNormal}`,
          '#ff8ed7',
          -50,
          900,
          1
        );
        blocks.splice(i,1);
        break;
      }
      case 'bomb': {
        if (!SNIP_POWERUP.allowBombRemoval) break;
        bombsTouched++;
        if (SNIP_POWERUP.bombTriggersExplosion) {
          if (!b.exploding) {
            b.exploding = true;
            b.explodeStart = now;
            spawnBombShards(b);
            spawnRingPulse(
              b.x + b.w/2,
              b.y + b.h/2,
              'rgba(255,110,60,0.55)',
              90,
              500
            );
            playSfx('bombExplode');
          }
        } else {
          blocks.splice(i,1);
        }
        break;
      }
      case 'life': {
        const cx = b.x + b.w/2;
        const cy = b.y + b.h/2;
        spawnPowerupVanishFX({
          x: cx, y: cy,
            img: lifeImg, imgReady: lifeImgReady,
          label: LIFE_BLOCK.label,
          color: LIFE_BLOCK.glowColor,
          iconScale: LIFE_BLOCK.iconScale,
          baseRadius: b.w/2
        });
        if (lives < LIFE_BLOCK.maxLives) {
          lives++;
          lifeCollectedCount++;
          spawnFloatText(cx, cy - 10, '+1 LIFE', '#20d672', -60, 1000, 1.05);
          spawnCatchParticles(cx, cy, '#20d672', 14);
        } else {
          spawnFloatText(cx, cy - 10, 'MAX', '#cccccc', -50, 900, 1);
        }
        blocks.splice(i,1);
        break;
      }
      case 'shield': {
        const cx = b.x + b.w/2;
        const cy = b.y + b.h/2;
        spawnPowerupVanishFX({
          x: cx, y: cy,
          img: shieldImg, imgReady: shieldImgReady,
          label: b.label,
          color: SHIELD_POWERUP.glow,
          iconScale: SHIELD_POWERUP.iconScale,
          baseRadius: b.w/2
        });
        shieldCollected = true;
        blocks.splice(i,1);
        break;
      }
      case 'taskmgr': {
        const cx = b.x + b.w/2;
        const cy = b.y + b.h/2;
        spawnPowerupVanishFX({
          x: cx, y: cy,
          img: taskMgrImg, imgReady: taskMgrImgReady,
          label: b.label,
          color: TASKMGR_POWERUP.glow,
          iconScale: TASKMGR_POWERUP.iconScale,
          baseRadius: b.w/2
        });
        taskMgrCollected = true;
        blocks.splice(i,1);
        break;
      }
      // case 'snip': {
      //   extraSnipCharge = true;
      //   blocks.splice(i,1);
      //   break;
      // }
      default:
        break;
    }
  }

  if (!normalCleared && !bombsTouched && !lifeCollectedCount && !shieldCollected && !taskMgrCollected) {
    spawnFloatText(
      rect.x + rect.w/2,
      rect.y + rect.h/2,
      'NO TARGETS',
      '#bcbcbc',
      -60,
      850,
      1
    );
  } else {
    const ringColor =
      taskMgrCollected ? 'rgba(255,210,90,0.55)' :
      shieldCollected   ? 'rgba(120,200,255,0.55)' :
      lifeCollectedCount? 'rgba(32,214,114,0.55)' :
      'rgba(255,63,177,0.40)';
    spawnRingPulse(
      rect.x + rect.w/2,
      rect.y + rect.h/2,
      ringColor,
      Math.min(260, Math.max(rect.w, rect.h) * 0.9),
      750
    );
  }

  if (shieldCollected) activateShield();
  if (taskMgrCollected) activateTaskManager();
  // if (extraSnipCharge) beginSnipReady();

  resetSnipState();
}
function cancelSnip() {
  if (!snipReady) return;
  playSfx('snipCancel');
  spawnFloatText(canvas.width / 2, canvas.height * 0.4, 'SNIP CANCELED', '#ff6f9f', -80, 1000, 1.1);
  resetSnipState();
}

/* -------------------- Shield Power-Up -------------------- */
function maybeSpawnShield(ts) {
  if (!SHIELD_POWERUP.enabled) return;
  if (bossActive || bossDying || shieldActive) return;
  if (!gameActive) return;
  if (countActiveShieldPowerups() >= SHIELD_POWERUP.maxConcurrent) return;
  const elapsed = ts - lastShieldSpawn;
  if (elapsed < nextShieldSpawnDelay) return;
  const ratio = Math.min(1, score / SHIELD_POWERUP.spawnIntervalDecayScore);
  const baseI = SHIELD_POWERUP.baseSpawnInterval -
    (SHIELD_POWERUP.baseSpawnInterval - SHIELD_POWERUP.spawnIntervalMin) * ratio;
  let cycles = 1;
  if (SHIELD_POWERUP.backfillCatchUp) cycles = Math.min(3, Math.max(1, Math.floor(elapsed / baseI)));
  if (cycles > 0) { spawnShieldPowerup(); lastShieldSpawn = ts; }
  nextShieldSpawnDelay = baseI + Math.random() * SHIELD_POWERUP.randomJitter;
}
function countActiveShieldPowerups() { return blocks.filter(b => b.mode === 'shield' && !b.caught).length; }
function spawnShieldPowerup() {
  loadShieldImage();
  const size = SHIELD_POWERUP.size;
  const x = Math.random() * (canvas.width - size - 80) + 40;
  const speed = randBetween(150, 280);
  blocks.push({
    mode: 'shield',
    label: SHIELD_POWERUP.label,
    x, y: -size - 10,
    w: size, h: size,
    speed,
    caught: false,
    created: performance.now()
  });
  playSfx('shieldSpawn');
}
function activateShield() {
  const extending = shieldActive;
  shieldActive = true;
  shieldEndTime = performance.now() + SHIELD_POWERUP.durationMs;
  playSfx('shieldPickup');
  spawnRingPulse(paddleX + DIFFICULTY.paddleWidth / 2,
    canvas.height - 90 + DIFFICULTY.paddleHeight / 2,
    'rgba(90,190,255,0.6)', 180, 800);
  spawnFloatText(paddleX + DIFFICULTY.paddleWidth / 2,
    canvas.height - 140,
    extending ? 'SHIELD REFRESH' : 'SHIELD ON',
    '#64c9ff', -80, 1200, 1.1);
}
function maybeExpireShield() {
  if (shieldActive && performance.now() >= shieldEndTime) {
    shieldActive = false;
    playSfx('shieldExpire');
    spawnFloatText(paddleX + DIFFICULTY.paddleWidth / 2,
      canvas.height - 140, 'SHIELD OFF', '#9fb6c2', -70, 1000, 1);
  }
}
function renderShieldAura() {
  if (!shieldActive) return;
  const t = (performance.now() % 1000) / 1000;
  const pulse = 0.6 + 0.4 * Math.sin(t * SHIELD_POWERUP.auraPulseSpeed * Math.PI * 2);
  const px = paddleX + DIFFICULTY.paddleWidth / 2;
  const py = canvas.height - 90 + DIFFICULTY.paddleHeight / 2;
  const radius = Math.max(DIFFICULTY.paddleWidth, 130) * 0.5 +
    SHIELD_POWERUP.auraRadiusExtra * (0.7 + 0.3 * pulse);
  ctx.save(); ctx.globalAlpha = 0.55;
  ctx.strokeStyle = SHIELD_POWERUP.auraTrailColor;
  ctx.lineWidth = 10; ctx.beginPath();
  ctx.arc(px, py, radius + 8, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.globalAlpha = 0.9;
  ctx.strokeStyle = SHIELD_POWERUP.auraColor;
  ctx.lineWidth = 4 + 2 * pulse;
  ctx.beginPath(); ctx.arc(px, py, radius, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  ctx.save(); ctx.globalAlpha = 0.15 * pulse;
  ctx.fillStyle = SHIELD_POWERUP.overlayFlashColor;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
}

/* -------------------- Task Manager Power-Up -------------------- */
function maybeSpawnTaskMgr(ts) {
  if (!TASKMGR_POWERUP.enabled) return;
  if (bossActive || bossDying) return;
  if (!gameActive) return;
  if (countActiveTaskMgr() >= TASKMGR_POWERUP.maxConcurrent) return;
  const elapsed = ts - lastTaskMgrSpawn;
  if (elapsed < nextTaskMgrSpawnDelay) return;
  const ratio = Math.min(1, score / TASKMGR_POWERUP.spawnIntervalDecayScore);
  const baseI = TASKMGR_POWERUP.baseSpawnInterval -
    (TASKMGR_POWERUP.baseSpawnInterval - TASKMGR_POWERUP.spawnIntervalMin) * ratio;
  let cycles = 1;
  if (TASKMGR_POWERUP.backfillCatchUp) cycles = Math.min(2, Math.max(1, Math.floor(elapsed / baseI)));
  if (cycles > 0) { spawnTaskMgrPowerup(); lastTaskMgrSpawn = ts; }
  nextTaskMgrSpawnDelay = baseI + Math.random() * TASKMGR_POWERUP.randomJitter;
}
function countActiveTaskMgr() { return blocks.filter(b => b.mode === 'taskmgr' && !b.caught).length; }
function spawnTaskMgrPowerup() {
  loadTaskMgrImage();
  const size = TASKMGR_POWERUP.size;
  const x = Math.random() * (canvas.width - size - 80) + 40;
  const speed = randBetween(130, 240);
  blocks.push({
    mode: 'taskmgr',
    label: TASKMGR_POWERUP.label,
    x, y: -size - 10,
    w: size, h: size,
    speed,
    caught: false,
    created: performance.now()
  });
  playSfx('taskmgrSpawn');
}
function activateTaskManager() {
  playSfx('taskmgrPickup');
  playSfx('taskmgrExecute');
  spawnRingPulse(canvas.width / 2, canvas.height / 2,
    TASKMGR_POWERUP.glow, TASKMGR_POWERUP.ringRadius, 900);
  if (TASKMGR_POWERUP.globalFlash) flashBG(TASKMGR_POWERUP.globalFlash);
  if (TASKMGR_POWERUP.screenShake)
    triggerShake(TASKMGR_POWERUP.shakeIntensity, TASKMGR_POWERUP.shakeDuration, 'all');
  let clearedNormal = 0;
  const now = performance.now();
  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i];
    if (['life', 'snip', 'shield', 'taskmgr', 'bossHazard'].includes(b.mode)) continue;
    if (b.mode === 'normal') {
      clearedNormal++;
      score += TASKMGR_POWERUP.awardScorePerNormal;
      spawnCatchParticles(b.x + b.w / 2, b.y + b.h / 2, '#ffd24d', 14);
      spawnFloatText(b.x + b.w / 2, b.y + b.h / 2, '+' + TASKMGR_POWERUP.awardScorePerNormal,
        '#ffdf80', -60, 850, 1);
      blocks.splice(i, 1);
      continue;
    }
    if (b.mode === 'bomb' && TASKMGR_POWERUP.affectBombs) {
      if (TASKMGR_POWERUP.bombExplode) {
        if (!b.exploding) {
          b.exploding = true; b.explodeStart = now;
          spawnBombShards(b);
          spawnRingPulse(b.x + b.w / 2, b.y + b.h / 2, 'rgba(255,140,50,0.55)', 90, 520);
          playSfx('bombExplode');
        }
      } else blocks.splice(i, 1);
    }
  }
  spawnFloatText(canvas.width / 2, canvas.height / 2 - 40,
    clearedNormal ? `TASK MANAGER: Cleared ${clearedNormal}` : 'TASK MANAGER: No Blocks',
    '#ffe684', -90, 1400, 1.15);

  if (TASKMGR_POWERUP.slowMoEnabled) {
    slowMoActive = true;
    slowMoFactor = TASKMGR_POWERUP.slowMoFactor;
    slowMoEnd = performance.now() + TASKMGR_POWERUP.slowMoDurationMs;
  }
}

/* -------------------- Intersection & Shake -------------------- */
function intersectRect(x1, y1, w1, h1, x2, y2, w2, h2) {
  return !(x2 > x1 + w1 || x2 + w2 < x1 || y2 > y1 + h1 || y2 + h2 < y1);
}
function triggerShake(intensity, duration, mode = 'all') {
  shakeIntensity = intensity;
  shakeDuration = duration;
  shakeStart = performance.now();
  shakeMode = mode;
}

/* -------------------- Boss Death Animation -------------------- */
function startBossDeathAnimation() {
  bossDying = true;
  bossDeathStart = performance.now();
  bossDeathParticles = [];
  spawnBossDeathParticles();
  triggerShake(SHAKE_DEATH_INTENSITY, SHAKE_DEATH_DURATION, 'all');
  playSfx('bossDeath');
}
function spawnBossDeathParticles() {
  const box = {
    x: canvas.width / 2 - BOSS_CONFIG.width / 2,
    y: BOSS_CONFIG.topY,
    w: BOSS_CONFIG.width,
    h: BOSS_CONFIG.height
  };
  for (let i = 0; i < BOSS_DEATH_PARTICLE_COUNT; i++) {
    const px = box.x + Math.random() * box.w;
    const py = box.y + Math.random() * box.h;
    const size = randBetween(...BOSS_DEATH_PARTICLE_SIZE);
    const speed = randBetween(...BOSS_DEATH_PARTICLE_SPEED);
    const angle = Math.random() * Math.PI * 2;
    const vx = Math.cos(angle) * speed;
    const vy = Math.sin(angle) * speed - randBetween(40, 120);
    const spin = randBetween(...BOSS_DEATH_PARTICLE_SPIN);
    bossDeathParticles.push({
      x: px, y: py, w: size, h: size, vx, vy, rot: 0, spin,
      born: performance.now(),
      life: BOSS_DEATH_PARTICLE_LIFE,
      col: Math.random() < 0.3 ? '#0078d7' : '#ffffff'
    });
  }
}
function drawBossDeathParticles(dt) {
  const now = performance.now();
  for (let i = bossDeathParticles.length - 1; i >= 0; i--) {
    const p = bossDeathParticles[i];
    const age = now - p.born;
    if (age > p.life) { bossDeathParticles.splice(i, 1); continue; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.rot += p.spin * dt;
    const fade = 1 - age / p.life;
    ctx.save(); ctx.globalAlpha = fade;
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot * Math.PI / 180);
    ctx.fillStyle = p.col;
    ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
    ctx.restore();
  }
}
function updateBossDeathAnimation(ts) {
  const elapsed = ts - bossDeathStart;
  const progress = Math.min(1, elapsed / BOSS_DEATH_DURATION);
  const flashOn = Math.floor(elapsed / BOSS_DEATH_FLASH_FREQ) % 2 === 0;
  const shrink = 1 - 0.65 * progress;
  const boxX = canvas.width / 2 - BOSS_CONFIG.width / 2;
  ctx.clearRect(boxX - 4, BOSS_CONFIG.topY - 50,
    BOSS_CONFIG.width + 8, BOSS_CONFIG.height + 120);
  if (progress < 0.98) {
    ctx.save();
    ctx.translate(canvas.width / 2, BOSS_CONFIG.topY + BOSS_CONFIG.height / 2);
    ctx.fillStyle = flashOn ? '#ffffff' : '#dfe9ff';
    roundedRect(ctx,
      -(BOSS_CONFIG.width * shrink) / 2,
      -(BOSS_CONFIG.height * shrink) / 2,
      BOSS_CONFIG.width * shrink,
      BOSS_CONFIG.height * shrink,
      24 * shrink);
    ctx.restore();
  }
  const dt = (ts - lastTs) / 1000;
  drawBossDeathParticles(dt);
  if (elapsed >= BOSS_DEATH_DURATION && bossDeathParticles.length === 0) {
    ctx.clearRect(boxX - 6, BOSS_CONFIG.topY - 60, BOSS_CONFIG.width + 12, BOSS_CONFIG.height + 140);
    bossDying = false;
    playSfx('bossDeathFinal');
    endGame(true);
  }
}

/* -------------------- FX Helpers -------------------- */
function spawnCatchParticles(cx, cy, baseColor, count = CATCH_PARTICLE_COUNT_BASE) {
  for (let i = 0; i < count; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = randBetween(60, 180);
    catchParticles.push({
      x: cx, y: cy,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd - randBetween(20, 60),
      size: randBetween(3, 7),
      color: baseColor,
      life: 0,
      maxLife: 550 + Math.random() * 350
    });
  }
}
function spawnFloatText(x, y, text, color = '#ffffff', rise = -50, dur = 900, scale = 1) {
  floatTexts.push({ x, y, vy: rise / dur, text, color, life: 0, maxLife: dur, scale });
}
function spawnRingPulse(x, y, color = 'rgba(32,214,114,0.55)', radius = LIFE_PULSE_RADIUS, dur = 600) {
  ringPulses.push({
    x, y, rFrom: 8, rTo: radius,
    life: 0, maxLife: dur,
    color,
    alphaFrom: .65, alphaTo: 0
  });
}
function updateAndRenderFX(dtMs) {
  // Particles
  for (let i = catchParticles.length - 1; i >= 0; i--) {
    const p = catchParticles[i];
    p.life += dtMs;
    if (p.life > p.maxLife) { catchParticles.splice(i, 1); continue; }
    const t = p.life / p.maxLife;
    p.x += p.vx * (dtMs / 1000);
    p.y += p.vy * (dtMs / 1000);
    p.vy += 120 * (dtMs / 1000);
    ctx.save(); ctx.globalAlpha = 1 - t;
    ctx.fillStyle = p.color;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 - 0.5 * t), 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
  // Float texts
  for (let i = floatTexts.length - 1; i >= 0; i--) {
    const f = floatTexts[i];
    f.life += dtMs;
    if (f.life > f.maxLife) { floatTexts.splice(i, 1); continue; }
    f.y += f.vy * dtMs;
    const t = f.life / f.maxLife;
    ctx.save(); ctx.globalAlpha = 1 - t;
    ctx.fillStyle = f.color;
    ctx.font = `600 ${14 * f.scale}px Segoe UI,Inter,sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(f.text, f.x, f.y);
    ctx.restore();
  }
  // Ring pulses
  for (let i = ringPulses.length - 1; i >= 0; i--) {
    const r = ringPulses[i];
    r.life += dtMs;
    if (r.life > r.maxLife) { ringPulses.splice(i, 1); continue; }
    const t = r.life / r.maxLife;
    const radius = r.rFrom + (r.rTo - r.rFrom) * t;
    const alpha = r.alphaFrom + (r.alphaTo - r.alphaFrom) * t;
    ctx.save();
    ctx.strokeStyle = r.color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = 6 * (1 - t);
    ctx.beginPath(); ctx.arc(r.x, r.y, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

/* -------------------- End Game Handling -------------------- */
function endGame(victory = false) {
  if (nukeTriggered) return;
  if (victory) unlockInfinite();

  if (infiniteMode) {
    if (!victory && REDIRECT_ON_LOSS) {
      playSfx('gameOver');
      window.location.href = LOSS_REDIRECT_URL;
      return;
    }
    finalizeInfiniteScreen(); return;
  }

const flawless = victory && !lifeEverLost;
const shouldNuke = (!victory) || (victory && REQUIRE_PERFECT_VICTORY && lifeEverLost);

  if (shouldNuke) {
    if (REDIRECT_ON_LOSS) {
      playSfx('gameOver');
      window.location.href = LOSS_REDIRECT_URL;
      return;
    }
    playSfx('nuke');
    triggerNuke(!victory ? 'Defenses collapsed.' :
      'Win detected, but insufficient purity (lives lost).');
    gameActive = false; nukeTriggered = true; return;
  }

  gameActive = false;
  updateHighScoreIfNeeded();

  if (flawless && SHOW_ESU_SCREEN) {
    playSfx('flawless');
    msgEl.innerHTML = `
      <div style="display:flex;flex-direction:column;align-items:center;gap:1.1rem;max-width:600px;">
        <h2 style="margin:0;font-weight:300;letter-spacing:1px;font-size:2.2rem;">Extended Security Updates Granted</h2>
        <p style="margin:0;line-height:1.4;">You defeated <strong>${BOSS_CONFIG.label}</strong> without losing a single life.</p>
        <p style="margin:0;font-size:.8rem;opacity:.75;">Score: ${score} — High: ${highScore}${newHigh ? ' <span class="tag-new">NEW!</span>' : ''}</p>
        <div style="display:flex;flex-wrap:wrap;gap:.6rem;justify-content:center;">
          <button class="esu-btn" data-act="infinite">Infinite (I)</button>
            <button class="esu-btn" data-act="replay">Replay (R)</button>
            <button class="esu-btn" data-act="exit">Exit (Esc)</button>
        </div>
      </div>`;
    styleESUButtons(); msgEl.classList.add('show'); wireESUButtons(); return;
  }

  playSfx('victory');
  msgEl.innerHTML =
    `Victory!${flawless ? ' (Flawless!)' : ''}<br>` +
    `<span style="font-size:.6em;opacity:.85">Score: ${score} — High: ${highScore}` +
    `${newHigh ? ' <span class="tag-new">NEW!</span>' : ''}<br>` +
    `I: Infinite (NEW) &nbsp; R: Replay &nbsp; Esc: Exit</span>`;
  msgEl.classList.add('show');
}
function styleESUButtons() {
  if (document.getElementById('esu-btn-styles')) return;
  const s = document.createElement('style');
  s.id = 'esu-btn-styles';
  s.textContent = `
    .esu-btn{background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.3);
      color:#fff;padding:.55rem 1.1rem;font:inherit;font-size:.7rem;letter-spacing:.7px;
      cursor:pointer;border-radius:8px;transition:background .2s,transform .15s;}
    .esu-btn:hover{background:rgba(255,255,255,0.28);}
    .esu-btn:active{transform:scale(.94);}
  `;
  document.head.appendChild(s);
}
function wireESUButtons() {
  msgEl.querySelectorAll('.esu-btn').forEach(b => {
    b.addEventListener('click', () => {
      playSfx('uiSelect');
      const act = b.dataset.act;
      if (act === 'infinite') startInfiniteGame();
      else if (act === 'replay') startGame();
      else if (act === 'exit') exitGame();
    });
  });
}
function finalizeInfiniteScreen() {
  gameActive = false;
  updateHighScoreIfNeeded();
  playSfx('gameOver');
  msgEl.innerHTML =
    `Infinite Mode Over<br>` +
    `<span style="font-size:.6em;opacity:.85">Score: ${score} — High: ${highScore}` +
    `${newHigh ? ' <span class="tag-new">NEW!</span>' : ''}<br>` +
    `I: Restart Infinite &nbsp; G: Boss Mode &nbsp; Esc: Exit</span>`;
  msgEl.classList.add('show');
}
function updateHighScoreIfNeeded() {
  if (score > highScore) {
    highScore = score; newHigh = true;
    try { localStorage.setItem(HIGH_SCORE_KEY, highScore); } catch { }
  }
}

/* -------------------- Spawning Normal / Hazards -------------------- */
function spawnBlock() {
  if (bossActive || bossDying || (!infiniteMode && score >= BOSS_CONFIG.triggerScore && !bossActive)) return;
  const tier = SIZE_TIERS[Math.floor(Math.random() * SIZE_TIERS.length)];
  const paddingX = 14;
  ctx.save();
  ctx.font = BLOCK_STYLE.textFont;
  const textW = ctx.measureText(tier.label).width;
  ctx.restore();
  const w = Math.max(54, Math.ceil(textW + paddingX * 2));
  const h = 36;
  const x = Math.random() * (canvas.width - w - 80) + 40;
  const baseSpeed = randBetween(...DIFFICULTY.baseSpeedRange);
  const speed = baseSpeed * tier.speedFactor * (1 + score * DIFFICULTY.scoreSpeedFactor);
  blocks.push({
    mode: 'normal',
    label: tier.label,
    textColor: tier.textColor,
    glowColor: tier.glowColor,
    x, y: -h - 10,
    w, h,
    speed,
    caught: false
  });
}
function spawnBossHazard() {
  if (bossDying) return;
  const hz = HAZARDS[Math.floor(Math.random() * HAZARDS.length)];
  const paddingX = 16;
  ctx.save();
  ctx.font = '600 18px Segoe UI,Inter,sans-serif';
  const textW = ctx.measureText(hz.label).width;
  ctx.restore();
  const w = Math.max(130, Math.ceil(textW + paddingX * 2));
  const h = 42;
  const x = Math.random() * (canvas.width - w - 160) + 80;
  const baseSpeed = randBetween(...BOSS_CONFIG.dropSpeedRange);
  const speed = baseSpeed * HAZARD_SPEED[hz.class];
  blocks.push({
    mode: 'bossHazard',
    label: hz.label,
    hazardClass: hz.class,
    color: hz.color,
    textColor: hz.text,
    x, y: BOSS_CONFIG.topY + BOSS_CONFIG.height,
    w, h, speed, caught: false
  });
}

/* -------------------- Boss Lifecycle -------------------- */
function maybeStartBoss() {
  if (infiniteMode || bossDying) return;
  if (!bossActive && score >= BOSS_CONFIG.triggerScore) {
    bossActive = true;
    bossStartTime = performance.now();
    blocks = [];
    flashBG('rgba(255,255,255,0.55)');
    playSfx('bossSpawn');
    resetSnipState();
    shieldActive = false;
  }
}
function updateBoss(ts) {
  if (bossDying) return;
  const t = (ts - bossStartTime) / 1000;
  const centerX = canvas.width / 2;
  const bossX = centerX + Math.sin(t * BOSS_CONFIG.moveSpeed) * BOSS_CONFIG.moveAmplitude - BOSS_CONFIG.width / 2;

  ctx.fillStyle = '#ffffff';
  roundedRect(ctx, bossX, BOSS_CONFIG.topY, BOSS_CONFIG.width, BOSS_CONFIG.height, 24);

  ctx.font = '600 30px Segoe UI,Inter,sans-serif';
  ctx.textBaseline = 'middle';
  const label = BOSS_CONFIG.label;
  const metrics = ctx.measureText(label);
  const textWidth = metrics.width;

  const logoMaxH = BOSS_CONFIG.height * 0.70;
  let logoW = logoMaxH, logoH = logoMaxH;
  if (bossLogoReady && bossLogoImg?.naturalWidth) {
    const ratio = bossLogoImg.naturalWidth / bossLogoImg.naturalHeight;
    logoH = logoMaxH; logoW = logoMaxH * ratio;
  }
  const spacing = 18;
  const totalWidth = logoW + spacing + textWidth;
  const startX = bossX + (BOSS_CONFIG.width - totalWidth) / 2;
  const cY = BOSS_CONFIG.topY + BOSS_CONFIG.height / 2;

  if (bossLogoReady) {
    ctx.drawImage(bossLogoImg, startX, cY - logoH / 2, logoW, logoH);
  } else {
    ctx.fillStyle = '#0078d7';
    ctx.fillRect(startX, cY - logoH / 2, logoW, logoH);
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 18px Segoe UI,Inter,sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('M', startX + logoW / 2, cY + 2);
    ctx.font = '600 30px Segoe UI,Inter,sans-serif';
  }

  ctx.fillStyle = '#0078d7';
  ctx.textAlign = 'left';
  ctx.fillText(label, startX + logoW + spacing, cY + 2);

  const barW = 460, barH = 16;
  const hbX = canvas.width / 2 - barW / 2;
  const hbY = BOSS_CONFIG.topY - 30;
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  roundedRect(ctx, hbX, hbY, barW, barH, 8);
  const pct = bossHealth / BOSS_CONFIG.health;
  ctx.fillStyle = pct > .5 ? '#20d672' : (pct > .25 ? '#ffc14d' : '#ff5a5a');
  roundedRect(ctx, hbX, hbY, barW * pct, barH, 8);

  const now = performance.now();
  if (now - lastBossDrop > bossDropInterval) {
    spawnBossHazard();
    lastBossDrop = now;
  }
}

/* -------------------- Bomb Drawing & Explosion -------------------- */
function drawBomb(b, now) {
  if (b.exploding) { drawBombExplosion(b, now); return; }
  const t = (now - b.created) / 1000;
  const pulse = 0.85 + 0.15 * Math.sin(t * BOMB_CONFIG.pulseSpeed * Math.PI);
  const rBase = b.w / 2;
  const r = rBase * pulse;
  ctx.save();
  ctx.translate(b.x + rBase, b.y + rBase);
  if (bombImgReady) {
    ctx.save(); ctx.globalAlpha = 0.35;
    ctx.fillStyle = BOMB_CONFIG.colorGlow;
    ctx.beginPath(); ctx.arc(0, 0, r + 8, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(bombImg, -r, -r, r * 2, r * 2);
    ctx.imageSmoothingEnabled = prev;
  } else {
    ctx.fillStyle = BOMB_CONFIG.colorBody;
    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = BOMB_CONFIG.colorOutline; ctx.stroke();
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = BOMB_CONFIG.colorGlow;
    ctx.beginPath(); ctx.arc(0, 0, r + 6, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  }
  const fuseLen = 14;
  ctx.strokeStyle = BOMB_CONFIG.colorFuse;
  ctx.lineWidth = 4; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(0, -r + 4); ctx.lineTo(0, -r - fuseLen); ctx.stroke();
  if (now - b.lastSpark > BOMB_CONFIG.fuseSparkEvery) {
    b.lastSpark = now;
    playSfx('bombTick', { allowOverlap: true });
    spawnFuseSpark(b.x + rBase, b.y + rBase - r - fuseLen);
  }
  ctx.restore();
}
function drawBombExplosion(b, now) {
  const elapsed = now - b.explodeStart;
  const t = Math.min(1, elapsed / BOMB_EXPLOSION_DURATION);
  const scale = 1 + 1.8 * t;
  const alpha = 1 - t;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(b.x + b.w / 2, b.y + b.h / 2);
  ctx.scale(scale, scale);
  if (bombImgReady) {
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(bombImg, -b.w / 2, -b.h / 2, b.w, b.h);
    ctx.imageSmoothingEnabled = prev;
  } else {
    ctx.fillStyle = '#ff9060';
    ctx.beginPath(); ctx.arc(0, 0, b.w / 2, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();

  b.shards.forEach(sh => {
    sh.x += sh.vx * sh.dt;
    sh.y += sh.vy * sh.dt;
    sh.vy += 180 * sh.dt;
    sh.rot += sh.spin * sh.dt;
    const age = now - sh.start;
    const fade = 1 - age / sh.life;
    ctx.save(); ctx.globalAlpha = fade;
    ctx.translate(sh.x, sh.y);
    ctx.rotate(sh.rot);
    ctx.fillStyle = sh.col;
    ctx.fillRect(-sh.size / 2, -sh.size / 2, sh.size, sh.size);
    ctx.restore();
  });
  b.shards = b.shards.filter(sh => now - sh.start < sh.life);
  if (elapsed > BOMB_EXPLOSION_DURATION && b.shards.length === 0) b._remove = true;
}
function spawnBombShards(b) {
  const cx = b.x + b.w / 2;
  const cy = b.y + b.h / 2;
  for (let i = 0; i < BOMB_SHARD_COUNT; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = randBetween(...BOMB_SHARD_SPEED);
    const size = randBetween(...BOMB_SHARD_SIZE);
    b.shards.push({
      x: cx, y: cy,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd - randBetween(40, 140),
      size,
      start: performance.now(),
      life: 400 + Math.random() * 400,
      rot: 0,
      spin: (Math.random() * 4 - 2) * 0.15,
      dt: 0
    });
  }
}
function spawnFuseSpark(x, y) {
  for (let i = 0; i < 4; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = randBetween(40, 90);
    catchParticles.push({
      x, y,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd - randBetween(10, 30),
      size: randBetween(2, 4),
      color: BOMB_CONFIG.colorSpark,
      life: 0,
      maxLife: 300 + Math.random() * 120
    });
  }
}
function handleBombHit(b) {
  if (b.exploding) return;
  b.exploding = true;
  b.explodeStart = performance.now();
  spawnBombShards(b);
  spawnRingPulse(b.x + b.w / 2, b.y + b.h / 2, 'rgba(255,90,50,0.55)', 110, 620);
  spawnCatchParticles(b.x + b.w / 2, b.y + b.h / 2, '#ff6430', 34);
  spawnFloatText(b.x + b.w / 2, b.y + b.h / 2 - 12, 'BOOM!', '#ff8259', -80, 1100, 1.25);
  playSfx('bombExplode');
  const startImmune = (performance.now() - gameStartTime) < START_IMMUNITY_MS;
  if (shieldActive) {
    playSfx('shieldBlock');
    spawnFloatText(b.x + b.w / 2, b.y + b.h / 2 + 10, 'BLOCKED', '#64c9ff', -70, 900, 1.05);
    return;
  }
  if (!(startImmune && BOMB_CONFIG.respectImmunity)) {
    lives -= BOMB_CONFIG.lifeCost;
    lifeEverLost = true; // mark that a life was lost this run
    flashBG(EFFECTS.missFlash);
    triggerShake(BOMB_CONFIG.shakeIntensity, BOMB_CONFIG.shakeDuration, 'y');
    if (lives <= 0) endGame(false);
    else spawnFloatText(b.x + b.w / 2, b.y + b.h / 2 + 8, `-${BOMB_CONFIG.lifeCost} LIFE`,
      '#ff6666', -60, 900, 1.1);
  } else {
    spawnFloatText(b.x + b.w / 2, b.y + b.h / 2 + 8, 'SAFE', '#8ae3ff', -50, 850, 1);
  }
}

/* -------------------- Simplified Drawing (Glow + Icon) -------------------- */
function drawSnipPowerup(b, now) {
  const t = (now - b.created) / 1000;
  const pulse = 0.85 + 0.15 * Math.sin(t * SNIP_POWERUP.pulseSpeed * Math.PI);
  const half = (b.w / 2) * pulse;
  ctx.save(); ctx.translate(b.x + b.w / 2, b.y + b.h / 2);
  ctx.globalAlpha = 0.55; ctx.fillStyle = SNIP_POWERUP.glow;
  ctx.beginPath(); ctx.arc(0, 0, half + 10, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
  if (snipImgReady) {
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(snipImg, -half, -half, half * 2, half * 2);
    ctx.imageSmoothingEnabled = prev;
  } else {
    ctx.fillStyle = SNIP_POWERUP.color;
    ctx.beginPath(); ctx.arc(0, 0, half, 0, Math.PI * 2); ctx.fill();
    ctx.font = '600 12px Segoe UI,Inter,sans-serif';
    ctx.fillStyle = SNIP_POWERUP.textColor;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(SNIP_POWERUP.label, 0, 1);
  }
  ctx.restore();
}
function drawShieldPowerup(b, now) {
  const t = (now - b.created) / 1000;
  const pulse = SHIELD_POWERUP.pulseScaleMin +
    ((Math.sin(t * SHIELD_POWERUP.pulseSpeed * Math.PI * 2) * 0.5 + 0.5) *
      (SHIELD_POWERUP.pulseScaleMax - SHIELD_POWERUP.pulseScaleMin));
  const r = (b.w / 2) * pulse;
  ctx.save(); ctx.translate(b.x + b.w / 2, b.y + b.h / 2);
  ctx.globalAlpha = 0.55; ctx.fillStyle = SHIELD_POWERUP.glow;
  ctx.beginPath(); ctx.arc(0, 0, r + 10, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
  if (shieldImgReady) {
    const iconSize = r * 2 * SHIELD_POWERUP.iconScale;
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(shieldImg, -iconSize / 2, -iconSize / 2, iconSize, iconSize);
    ctx.imageSmoothingEnabled = prev;
  } else if (SHIELD_POWERUP.showLabelFallback) {
    ctx.font = `700 ${Math.round(r * 0.9)}px Segoe UI,Inter,sans-serif`;
    ctx.fillStyle = SHIELD_POWERUP.textColor;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(SHIELD_POWERUP.label, 0, 2);
  }
  ctx.restore();
}
function drawTaskMgrPowerup(b, now) {
  const t = (now - b.created) / 1000;
  const pulse = TASKMGR_POWERUP.pulseScaleMin +
    ((Math.sin(t * TASKMGR_POWERUP.pulseSpeed * Math.PI * 2) * 0.5 + 0.5) *
      (TASKMGR_POWERUP.pulseScaleMax - TASKMGR_POWERUP.pulseScaleMin));
  const r = (b.w / 2) * pulse;
  ctx.save(); ctx.translate(b.x + b.w / 2, b.y + b.h / 2);
  ctx.globalAlpha = 0.6; ctx.fillStyle = TASKMGR_POWERUP.glow;
  ctx.beginPath(); ctx.arc(0, 0, r + 10, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
  if (taskMgrImgReady) {
    const iconSize = r * 2 * TASKMGR_POWERUP.iconScale;
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(taskMgrImg, -iconSize / 2, -iconSize / 2, iconSize, iconSize);
    ctx.imageSmoothingEnabled = prev;
  } else if (TASKMGR_POWERUP.showLabelFallback) {
    ctx.font = `700 ${Math.round(r * 0.9)}px Segoe UI,Inter,sans-serif`;
    ctx.fillStyle = TASKMGR_POWERUP.textColor;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(TASKMGR_POWERUP.label, 0, 2);
  }
  ctx.restore();
}
function drawLifeBlock(b, now) {
  const tLife = ((now - (b.created || now)) / 1000) * LIFE_BLOCK.pulseSpeed;
  const scale = LIFE_BLOCK.pulseScaleMin +
    ((Math.sin(tLife * Math.PI * 2) * 0.5 + 0.5) * (LIFE_BLOCK.pulseScaleMax - LIFE_BLOCK.pulseScaleMin));
  const baseR = b.w / 2;
  const r = baseR * scale;
  ctx.save(); ctx.translate(b.x + b.w / 2, b.y + b.h / 2);
  ctx.globalAlpha = 0.65; ctx.fillStyle = LIFE_BLOCK.glowColor;
  ctx.beginPath(); ctx.arc(0, 0, r + 10, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
  if (lifeImgReady) {
    const iconSize = r * 2 * LIFE_BLOCK.iconScale;
    const prev = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(lifeImg, -iconSize / 2, -iconSize / 2, iconSize, iconSize);
    ctx.imageSmoothingEnabled = prev;
  } else if (LIFE_BLOCK.showPlusFallback) {
    ctx.font = `700 ${Math.round(r * 0.9)}px Segoe UI,Inter,sans-serif`;
    ctx.fillStyle = LIFE_BLOCK.textColor;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(LIFE_BLOCK.label, 0, 2);
  }
  ctx.restore();
}

/* -------------------- Slow Motion -------------------- */
function adjustDtForSlowMo(rawDt) {
  if (!slowMoActive) return rawDt;
  if (performance.now() > slowMoEnd) {
    slowMoActive = false; slowMoFactor = 1; return rawDt;
  }
  return rawDt * slowMoFactor;
}

/* -------------------- Main Loop -------------------- */
function gameLoop(ts) {
  if (!gameActive || gamePaused || nukeTriggered) return;
  let rawDt = (ts - lastTs) / 1000;
  let dt = adjustDtForSlowMo(rawDt);
  const dtMs = (ts - lastTs);
  lastTs = ts;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  maybeStartBoss();
  if (!bossActive && !bossDying && !snipReady) {
    maybeSpawnBomb(ts);
    maybeSpawnSnip(ts);
    maybeSpawnShield(ts);
    maybeSpawnTaskMgr(ts);
  }
  maybeExpireShield();

  // Shake
  let offX = 0, offY = 0;
  if (shakeStart) {
    const et = performance.now() - shakeStart;
    if (et < shakeDuration) {
      const damp = 1 - et / shakeDuration;
      const j = shakeIntensity * damp;
      if (shakeMode === 'all') { offX = (Math.random() * 2 - 1) * j; offY = (Math.random() * 2 - 1) * j; }
      else if (shakeMode === 'x') { offX = (Math.random() * 2 - 1) * j; }
      else if (shakeMode === 'y') { offY = (Math.random() * 2 - 1) * j; }
    } else shakeStart = 0;
  }
  ctx.save(); ctx.translate(offX, offY);

  const paddleY = canvas.height - 90;
  if (!bossDying && ts - lastSpawn > spawnInterval) {
    spawnBlock(); lastSpawn = ts;
  }

  const now = performance.now();

  // Draw & advance
  for (const b of blocks) {
    if (!(b.mode === 'bomb' && b.exploding)) b.y += b.speed * dt;
    if (b.mode === 'bomb' && b.exploding) b.shards.forEach(sh => sh.dt = dt);

    if (b.mode === 'normal') drawNormalBlock(b);
    else if (b.mode === 'bossHazard') {
      ctx.fillStyle = b.caught ? 'rgba(255,255,255,0.15)' : b.color;
      roundedRect(ctx, b.x, b.y, b.w, b.h, 14);
      ctx.save();
      ctx.font = '600 18px Segoe UI,Inter,sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = b.caught ? 'rgba(255,255,255,0.55)' : b.textColor;
      ctx.fillText(b.label, b.x + b.w / 2, b.y + b.h / 2 + 1);
      ctx.restore();
    }
    else if (b.mode === 'life') drawLifeBlock(b, now);
    else if (b.mode === 'bomb') drawBomb(b, now);
    else if (b.mode === 'snip') drawSnipPowerup(b, now);
    else if (b.mode === 'shield') drawShieldPowerup(b, now);
    else if (b.mode === 'taskmgr') drawTaskMgrPowerup(b, now);
  }

  if (bossActive && !infiniteMode && !bossDying) updateBoss(ts);
  if (bossDying) updateBossDeathAnimation(ts);

  // Collisions
  if (!bossDying) {
    blocks.forEach(b => {
      if (b.mode === 'bomb' && b.exploding) return;
      if (!b.caught &&
        b.y + b.h >= paddleY &&
        b.y <= paddleY + DIFFICULTY.paddleHeight &&
        b.x + b.w >= paddleX &&
        b.x <= paddleX + DIFFICULTY.paddleWidth) {

        const centerX = b.x + b.w / 2;
        const centerY = b.y + b.h / 2;

        if (b.mode === 'taskmgr') {
          b.caught = true; b._removeImmediate = true;
          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: taskMgrImg, imgReady: taskMgrImgReady,
            label: b.label, color: TASKMGR_POWERUP.glow, iconScale: TASKMGR_POWERUP.iconScale, baseRadius: b.w / 2
          });
          activateTaskManager();
          return;
        }
        if (b.mode === 'snip') {
          b.caught = true; b._removeImmediate = true;
          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: snipImg, imgReady: snipImgReady,
            label: b.label, color: SNIP_POWERUP.glow, iconScale: 0.9, baseRadius: b.w / 2
          });
          beginSnipReady();
          spawnRingPulse(centerX, centerY, SNIP_POWERUP.glow, 90, 700);
          return;
        }
        if (b.mode === 'shield') {
          b.caught = true; b._removeImmediate = true;
          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: shieldImg, imgReady: shieldImgReady,
            label: b.label, color: SHIELD_POWERUP.glow, iconScale: SHIELD_POWERUP.iconScale, baseRadius: b.w / 2
          });
          activateShield();
          spawnRingPulse(centerX, centerY, SHIELD_POWERUP.glow, 100, 700);
          return;
        }
        if (b.mode === 'bomb') { handleBombHit(b); return; }

        if (b.mode === 'life') {
          b.caught = true; b._removeImmediate = true;
          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: lifeImg, imgReady: lifeImgReady,
            label: LIFE_BLOCK.label, color: LIFE_BLOCK.glowColor, iconScale: LIFE_BLOCK.iconScale, baseRadius: b.w / 2
          });
          if (lives < LIFE_BLOCK.maxLives) {
            lives++;
            spawnRingPulse(centerX, centerY, 'rgba(32,214,114,0.55)');
            spawnFloatText(centerX, centerY - 10, '+1 LIFE', '#20d672', -60, 1000, 1.05);
            spawnCatchParticles(centerX, centerY, '#20d672', 14);
            playSfx('lifeGain');
            triggerShake(6, 140, 'y');
          } else {
            spawnFloatText(centerX, centerY - 10, 'MAX', '#cccccc', -50, 900, 1);
            playSfx('lifeMax');
          }
          return;
        }

        // Normal block catch
        // Normal block catch
        b.caught = true;
        b._removeImmediate = true;

        if (bossActive) {
          // Boss damage path
          const dmg = BOSS_CONFIG.damagePerCatch;
          bossHealth -= dmg;
          if (bossHealth < 0) bossHealth = 0;
          score += dmg;

          flashBG(EFFECTS.catchFlash);
          playSfx('bossHit');
          triggerShake(SHAKE_DAMAGE_INTENSITY, SHAKE_DAMAGE_DURATION, 'all');

          // Visual FX (use orange-ish theme for boss hits)
          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: null, imgReady: false,
            label: b.label,
            color: 'rgba(255,159,64,0.50)',
            iconScale: 0.85,
            baseRadius: Math.min(b.w, b.h) / 2
          });
          spawnCatchParticles(centerX, centerY, '#ff9f40', 14);
          spawnFloatText(centerX, centerY - 14, `-${dmg}`, '#ffb14a', -70, 900, 1.05);

          maybeSpawnLifeBlock();

          // Adjust boss hazard drop interval as damage accumulates
          const totalDamageDone = BOSS_CONFIG.health - bossHealth;
          if (totalDamageDone > 0 &&
            totalDamageDone % BOSS_CONFIG.dropIntervalReduceEvery === 0) {
            bossDropInterval = Math.max(
              BOSS_CONFIG.dropIntervalMin,
              bossDropInterval - BOSS_CONFIG.dropIntervalReduceAmount
            );
          }

          if (bossHealth <= 0 && !bossDying) {
            startBossDeathAnimation();
          }
        } else {
          // Regular (pre‑boss / infinite) scoring path
          flashBG(EFFECTS.catchFlash);
          const tiny = SMALL_BLOCK_LABELS.has(b.label);
          score++;
          playSfx(tiny ? 'catchTiny' : 'catchBlock');
          const color = tiny ? '#ffd257' : '#58c2ff';

          spawnPowerupVanishFX({
            x: centerX, y: centerY, img: null, imgReady: false,
            label: b.label,
            color: tiny ? 'rgba(255,210,87,0.45)' : 'rgba(88,194,255,0.45)',
            iconScale: 0.8,
            baseRadius: Math.min(b.w, b.h) / 2
          });
          spawnCatchParticles(centerX, centerY, color, tiny ? 18 : CATCH_PARTICLE_COUNT_BASE);
          spawnFloatText(centerX, centerY - 12, '+1', color, -60, 800, 1);
          if (tiny) spawnRingPulse(centerX, centerY, 'rgba(255,210,87,0.55)', 60, 520);

          maybeSpawnLifeBlock();

          spawnInterval = Math.max(
            DIFFICULTY.minSpawnInterval,
            DIFFICULTY.baseSpawnInterval - score * DIFFICULTY.scoreSpawnReduction
          );
        }
      }
    });
  }

  // Miss / cleanup
  const nowTime = performance.now();
  const startImmune = (nowTime - gameStartTime) < START_IMMUNITY_MS;
  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i];
    if (b._removeImmediate) { blocks.splice(i, 1); continue; }
    if (b.mode === 'bomb' && b.exploding && b._remove) { blocks.splice(i, 1); continue; }
    if (!b.exploding && b.y > canvas.height + 60) {
      if (!b.caught) {
        if (b.mode === 'life') playSfx('lifeMiss');
        else if (b.mode === 'bomb') { /* silent */ }
        else if (['snip', 'shield', 'taskmgr'].includes(b.mode)) { /* missed power-up */ }
        else if (!startImmune && !bossDying) {
          if (shieldActive) {
            playSfx('shieldBlock');
            spawnFloatText(paddleX + DIFFICULTY.paddleWidth / 2,
              canvas.height - 130, 'BLOCKED', '#64c9ff', -60, 900, 1);
          } else {
            lives--;
            lifeEverLost = true;
            flashBG(EFFECTS.missFlash);
            spawnFloatText(paddleX + DIFFICULTY.paddleWidth / 2,
              canvas.height - 100, '-1 LIFE', '#ff6666', -70, 950, 1.1);
            playSfx('miss');
            triggerShake(SHAKE_LIFE_LOST_INTENSITY, SHAKE_LIFE_LOST_DURATION, 'x');
            if (lives <= 0) endGame(false);
          }
        }
      }
      blocks.splice(i, 1);
    }
  }

  // Paddle
  drawTaskbarPaddle(paddleX, paddleY, DIFFICULTY.paddleWidth);

  // Shield aura
  renderShieldAura();

  // FX
  updateAndRenderFX(dtMs);
  updateRenderVanishFX(performance.now());

  // SNIP overlay
  if (snipReady && !bossActive && !bossDying) {
    renderSnipOverlay();
    if (performance.now() - snipAimStart > SNIP_POWERUP.aimTimeoutMs && !snipDragging) {
      cancelSnip();
    }
  }

  ctx.restore(); // shake
  updateHUD();
  if (gameActive && !nukeTriggered) rafId = requestAnimationFrame(gameLoop);
}

/* -------------------- SNIP Overlay Rendering -------------------- */
function renderSnipOverlay() {
  ctx.save();
  ctx.fillStyle = SNIP_POWERUP.fadeOverlay;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = '600 18px Segoe UI,Inter,sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.fillText('SNIP MODE: Drag to select area', canvas.width / 2, 70);
  const remaining = Math.max(0, SNIP_POWERUP.aimTimeoutMs - (performance.now() - snipAimStart));
  ctx.font = '500 13px Segoe UI,Inter,sans-serif';
  ctx.fillText(`${Math.ceil(remaining / 1000)}s`, canvas.width / 2, 96);
  if (snipRect) {
    ctx.strokeStyle = SNIP_POWERUP.outlineColor;
    ctx.lineWidth = SNIP_POWERUP.strokeWidth;
    ctx.strokeRect(snipRect.x, snipRect.y, snipRect.w, snipRect.h);
    ctx.fillStyle = SNIP_POWERUP.fillRectColor;
    ctx.fillRect(snipRect.x, snipRect.y, snipRect.w, snipRect.h);
  }
  ctx.restore();
}

/* -------------------- Pointer / Touch for SNIP -------------------- */
function pointerCanvasPos(e) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left) / rect.width * canvas.width,
    y: (e.clientY - rect.top) / rect.height * canvas.height
  };
}
function onPointerDown(e) {
  if (!snipReady) return;
  e.preventDefault();
  snipDragging = true;
  snipDragStarted = false;
  const p = pointerCanvasPos(e);
  snipDragOrigin = p;
  snipRect = { x: p.x, y: p.y, w: 0, h: 0 };
}
function onPointerMove(e) {
  if (!snipReady || !snipDragging) return;
  const p = pointerCanvasPos(e);
  const ox = snipDragOrigin.x, oy = snipDragOrigin.y;
  snipRect.x = Math.min(ox, p.x);
  snipRect.y = Math.min(oy, p.y);
  snipRect.w = Math.abs(p.x - ox);
  snipRect.h = Math.abs(p.y - oy);
  if (!snipDragStarted && (snipRect.w > 6 || snipRect.h > 6)) {
    snipDragStarted = true;
    playSfx('snipDragStart');
  }
}
function onPointerUp() {
  if (!snipReady || !snipDragging) return;
  snipDragging = false;
  if (snipDragStarted && snipRect && snipRect.w > 4 && snipRect.h > 4) {
    executeSnip(snipRect);
  } else {
    cancelSnip();
  }
}
function onTouchStart(e) {
  if (!snipReady) return;
  if (e.touches.length > 1) return;
  onPointerDown(e.touches[0]);
}
function onTouchDrag(e) {
  if (!snipReady) return;
  if (e.touches.length > 1) return;
  onPointerMove(e.touches[0]);
}
function onTouchEnd(e) {
  if (!snipReady) return;
  onPointerUp(e.changedTouches[0]);
}

/* -------------------- HUD -------------------- */
function updateHUD() {
  let line;
  if (infiniteMode) line = 'Mode: INFINITE';
  else if (bossDying) {
    const el = performance.now() - bossDeathStart;
    const pct = Math.min(100, Math.floor((el / BOSS_DEATH_DURATION) * 100));
    line = `Boss dismantling: ${pct}%`;
  } else if (bossActive) {
    line = `Boss HP: ${bossHealth}/${BOSS_CONFIG.health}`;
  } else {
    const toGoBoss = Math.max(0, BOSS_CONFIG.triggerScore - score);
    line = `Boss @ ${BOSS_CONFIG.triggerScore} (to go: ${toGoBoss})`;
  }

  let shieldTag = '';
  if (shieldActive) {
    const remain = Math.max(0, shieldEndTime - performance.now());
    shieldTag = ` <span style="color:${SHIELD_POWERUP.hudTagColor};">SHIELD ${Math.ceil(remain / 1000)}s</span>`;
  }
  const snipTag = snipReady ? ' <span style="color:#ff89d2;">SNIP READY</span>' : '';
  const tmTag = slowMoActive ? ' <span style="color:#ffd24d;">TM SLOW-MO</span>' : '';

  hudEl.innerHTML =
    `Score: ${score}${(score > highScore) ? ' <span style="color:#20d672">(+)' : ''}` +
    `<br>High: ${highScore}${newHigh ? ' <span class="tag-new">NEW!</span>' : ''}` +
    `<br>Lives: ${lives}/${LIFE_BLOCK.maxLives}` +
    `<br>${line}${shieldTag}${snipTag}${tmTag}` +
    (infiniteUnlocked && !infiniteMode ? `<br><span style="opacity:.8">I: Infinite Mode</span>` : '') +
    (!bossDying ? `<br><span style="opacity:.7">P:Pause Esc:Exit</span>` : '');
}

/* -------------------- Visual Effects -------------------- */
function flashBG(color) {
  if (!overlayEl || nukeTriggered) return;
  overlayEl.style.background = color;
  if (flashBG._t) clearTimeout(flashBG._t);
  flashBG._t = setTimeout(() => {
    if (!nukeTriggered) overlayEl.style.background = BASE_OVERLAY_BG;
  }, EFFECTS.flashDuration);
}

/* -------------------- Input & Utility -------------------- */
function clampPaddle() {
  const m = DIFFICULTY.paddleEdgeMargin;
  if (paddleX < m) paddleX = m;
  if (paddleX + DIFFICULTY.paddleWidth > canvas.width - m)
    paddleX = canvas.width - m - DIFFICULTY.paddleWidth;
}
function resizeCanvas() {
  canvas.width = innerWidth;
  canvas.height = innerHeight;
  clampPaddle();
}
function onMouseMove(e) {
  if (!gameActive || gamePaused || nukeTriggered || bossDying) return;
  if (snipReady) return;
  const rect = canvas.getBoundingClientRect();
  paddleX = (e.clientX - rect.left) / rect.width * canvas.width - DIFFICULTY.paddleWidth / 2;
  clampPaddle();
}
function onTouchMove(e) {
  if (!gameActive || gamePaused || nukeTriggered || bossDying) return;
  if (snipReady) return;
  const t = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  paddleX = (t.clientX - rect.left) / rect.width * canvas.width - DIFFICULTY.paddleWidth / 2;
  clampPaddle();
}
function onGameKey(e) {
  if (nukeTriggered) return;
  if (!gameActive) {
    if (e.key === 'r' || e.key === 'R') (infiniteMode ? startInfiniteGame() : startGame());
    else if ((e.key === 'i' || e.key === 'I') && infiniteUnlocked) startInfiniteGame();
    else if (e.key === 'g' || e.key === 'G') startGame();
    else if (e.key === 'Escape') exitGame();
    if (['r', 'R', 'i', 'I', 'g', 'G'].includes(e.key)) playSfx('uiSelect');
    return;
  }
  if (bossDying) {
    if (e.key === 'Escape') { playSfx('uiSelect'); exitGame(); }
    return;
  }
  if (snipReady) {
    if (e.key === 'Escape') cancelSnip();
    return;
  }
  if (['ArrowLeft', 'a', 'A'].includes(e.key)) paddleX -= 55;
  else if (['ArrowRight', 'd', 'D'].includes(e.key)) paddleX += 55;
  else if (e.key === 'p' || e.key === 'P') { playSfx('uiSelect'); pauseGame(); }
  else if (e.key === 'Escape') { playSfx('uiSelect'); exitGame(); }
  clampPaddle();
}
function pauseGame() {
  if (!gameActive || nukeTriggered || bossDying) return;
  if (snipReady) return;
  gamePaused = !gamePaused;
  if (gamePaused) {
    msgEl.textContent = 'Paused';
    msgEl.classList.add('show');
  } else {
    msgEl.classList.remove('show');
    lastTs = performance.now();
    rafId = requestAnimationFrame(gameLoop);
  }
}
function exitGame() {
  cancelAnimationFrame(rafId);
  overlayEl.style.display = 'none';
  if (flashBG._t) { clearTimeout(flashBG._t); flashBG._t = null; }
  overlayEl.style.background = BASE_OVERLAY_BG;
  showPlayPrompt();
  window.removeEventListener('resize', resizeCanvas);
  window.removeEventListener('mousemove', onMouseMove);
  window.removeEventListener('touchmove', onTouchMove);
  window.removeEventListener('keydown', onGameKey);
  window.removeEventListener('mousedown', onPointerDown);
  window.removeEventListener('mouseup', onPointerUp);
  window.removeEventListener('mousemove', onPointerMove);
  window.removeEventListener('touchstart', onTouchStart);
  window.removeEventListener('touchend', onTouchEnd);
  window.removeEventListener('touchmove', onTouchDrag);
  gameActive = false;
  playSfx('uiSelect');
}

/* === START LIVES BANNER === */
function showStartLivesBanner() {
  // Use configured starting lives (dynamic if you ever change it)
  const startLives = DIFFICULTY.lives;

  // Remove any previous banner
  const old = document.getElementById('start-lives-banner');
  if (old) old.remove();

  const div = document.createElement('div');
  div.id = 'start-lives-banner';
  div.textContent = `${startLives} LIVES`;
  div.style.cssText = `
    position:fixed;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    font:700 clamp(3rem,10vw,6rem) "Segoe UI", Inter, system-ui, sans-serif;
    color:#ffffff;
    letter-spacing:.15em;
    text-shadow:0 0 14px rgba(0,180,255,0.55), 0 0 4px rgba(0,0,0,0.7);
    background:radial-gradient(circle at 50% 50%, rgba(0,80,140,0.35), rgba(0,0,0,0.85));
    backdrop-filter:blur(4px);
    animation: livesBannerFade 2.2s forwards;
    z-index:9998;
    pointer-events:none;
  `;
  document.body.appendChild(div);

  // Inject keyframes once
  if (!document.getElementById('start-lives-banner-style')) {
    const style = document.createElement('style');
    style.id = 'start-lives-banner-style';
    style.textContent = `
      @keyframes livesBannerFade {
        0% { opacity: 0; transform: scale(.85); }
        12% { opacity: 1; transform: scale(1); }
        70% { opacity: 1; }
        100% { opacity: 0; transform: scale(1.05); }
      }
    `;
    document.head.appendChild(style);
  }

  // Cleanup after animation
  setTimeout(() => {
    div.remove();
  }, 2300);
}
/* === END START LIVES BANNER === */

/* -------------------- Export API -------------------- */
export const GameAPI = {
  startGame,
  startInfiniteGame,
  showPlayPrompt
};